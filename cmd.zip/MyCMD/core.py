import os
import time
import json
import platform
import socket
import datetime
import shutil
import subprocess
from colorama import init, Fore, Back, Style

init(autoreset=True)

# Config
config = {
    "username": "Tahi-arii",
    "version": "1.0",
    "prompt_color": Fore.MAGENTA + Style.BRIGHT,
    "bg_color": Back.MAGENTA,
    "text_color": Fore.MAGENTA + Style.BRIGHT
}

# ------------- ANIMATION AU LANCEMENT -------------
def launch_animation():
    banner = [
        "████████╗ █████╗ ██╗  ██╗██╗██╗-██╗ ██████╗ ██╗███████╗",
        "╚══██╔══╝██╔══██╗██║ ██╔╝██║██║-██║██╔═══██╗██║██╔════╝",
        "   ██║   ███████║█████╔╝ ██║██║-██║██║   ██║██║█████╗  ",
        "   ██║   ██╔══██║██╔═██╗ ██║██║-██║██║   ██║██║██╔══╝  ",
        "   ██║   ██║  ██║██║  ██╗██║██║-██║╚██████╔╝██║███████╗",
        "   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═╝-╚═╝ ╚═════╝ ╚═╝╚══════╝"
    ]
    for line in banner:
        print(Fore.MAGENTA + Back.LIGHTMAGENTA_EX + line)
        time.sleep(0.2)
    time.sleep(0.5)
    clear()

# ------------- CLEAR SCREEN -------------
def clear():
    os.system("cls" if os.name == "nt" else "clear")

# ------------- HELP 50 COMMANDES -------------
def help_commands():
    commands = {
        "help": "Affiche cette liste des commandes",
        "clear": "Nettoie l'écran",
        "exit": "Quitte le CMD",
        "info": "Affiche les infos système",
        "time": "Affiche l'heure actuelle",
        "date": "Affiche la date actuelle",
        "user": "Nom de l'utilisateur",
        "version": "Version du CMD",
        "internet": "Vérifie si Internet est connecté",
        "ip": "Affiche l'adresse IP locale",
        "os": "Informations sur le système",
        "disk": "Infos disque dur",
        "ls": "Liste les fichiers du dossier courant",
        "pwd": "Chemin du dossier courant",
        "open": "Ouvre l'explorateur du dossier",
        "mkdir": "Créer un dossier",
        "rmdir": "Supprimer un dossier vide",
        "delete": "Supprime un fichier",
        "copy": "Copie un fichier",
        "move": "Déplace un fichier",
        "tasklist": "Liste les processus en cours",
        "kill": "Tue un processus par son nom",
        "cpu": "Affiche l'utilisation du CPU",
        "ram": "Affiche la RAM disponible",
        "reboot": "Redémarre l'ordinateur",
        "shutdown": "Éteint l'ordinateur",
        "/malware!": "Scan rapide antivirus Windows Defender",
        "banner": "Affiche une bannière stylée",
        "say": "Répète ce que vous tapez",
        "calc": "Calculatrice simple",
        "datefull": "Date et heure complètes",
        "network": "Affiche les infos réseau",
        "ping": "Ping un site ou IP",
        "weather": "Météo (à configurer manuellement)",
        "filesize": "Taille d'un fichier",
        "whoami": "Nom de l'utilisateur courant",
        "uptime": "Temps depuis le démarrage du système",
        "drives": "Liste tous les lecteurs",
        "cls": "Alias pour clear",
        "color": "Change la couleur du texte",
        "bgcolor": "Change la couleur du fond",
        "echo": "Affiche un texte personnalisé",
        "dir": "Liste fichiers du dossier (alias ls)",
        "help2": "Autre alias pour help",
        "versionfull": "Affiche toutes les infos du CMD",
        "pinggoogle": "Ping google.com",
        "calendar": "Affiche calendrier",
        "motd": "Message of the day",
        "todo": "Liste de tâches (exemple)",
        "animate": "Relance l'animation de démarrage",
        "networkinfo": "Affiche détails réseau",
        "rebootforce": "Redémarrage forcé"
    }
    print("\n--- COMMANDES DISPONIBLES ---")
    for cmd, desc in commands.items():
        print(f"{cmd:<15} - {desc}")
    print("-----------------------------\n")

# ------------- MAIN CMD -------------
def run():
    launch_animation()
    while True:
        cmd = input(config["prompt_color"] + "Tahi-arii> " + Style.RESET_ALL).strip().lower()

        # SORTIE
        if cmd == "exit":
            print("Au revoir !")
            break

        # HELP
        elif cmd == "help":
            help_commands()

        # CLEAR
        elif cmd in ["clear","cls"]:
            clear()

        # INFO SYSTEME
        elif cmd == "info":
            print(f"User: {config['username']}")
            print(f"Version: {config['version']}")
            print(f"Système: {platform.system()} {platform.release()}")

        # TEMPS ET DATE
        elif cmd == "time":
            print("Heure:", datetime.datetime.now().strftime("%H:%M:%S"))
        elif cmd == "date":
            print("Date:", datetime.datetime.now().strftime("%d/%m/%Y"))
        elif cmd == "datefull":
            print("Date & heure:", datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"))

        # USER & VERSION
        elif cmd == "user" or cmd == "whoami":
            print("Utilisateur:", os.getlogin())
        elif cmd == "version" or cmd == "versionfull":
            print(f"MyCMD v{config['version']} par {config['username']}")

        # INTERNET & RESEAU
        elif cmd == "internet":
            try:
                socket.create_connection(("8.8.8.8", 53), timeout=2)
                print("Internet: CONNECTÉ")
            except:
                print("Internet: OFFLINE")
        elif cmd == "ip":
            print("IP locale:", socket.gethostbyname(socket.gethostname()))
        elif cmd == "network":
            os.system("ipconfig" if os.name=="nt" else "ifconfig")
        elif cmd == "networkinfo":
            os.system("ipconfig /all" if os.name=="nt" else "ifconfig -a")
        elif cmd == "pinggoogle":
            os.system("ping google.com")

        # DISQUE
        elif cmd == "disk":
            total, used, free = shutil.disk_usage("C:\\")
            print("Disk utilisé:", used//(1024**3),"GB")
            print("Disk libre:", free//(1024**3),"GB")
        elif cmd == "drives":
            if os.name=="nt":
                for letter in "CDEFGHIJKLMNOPQRSTUVWXYZ":
                    if os.path.exists(f"{letter}:\\"):
                        print(letter+":\\")
            else:
                print("/")

        # FICHIERS
        elif cmd in ["ls","dir"]:
            for f in os.listdir():
                print(f)
        elif cmd == "pwd":
            print(os.getcwd())
        elif cmd.startswith("mkdir "):
            os.mkdir(cmd[6:])
        elif cmd.startswith("rmdir "):
            os.rmdir(cmd[6:])
        elif cmd.startswith("delete "):
            os.remove(cmd[7:])
        elif cmd.startswith("copy "):
            a,b = cmd.split()[1], cmd.split()[2]
            shutil.copy(a,b)
        elif cmd.startswith("move "):
            a,b = cmd.split()[1], cmd.split()[2]
            shutil.move(a,b)
        elif cmd == "open":
            os.system("explorer .")
        elif cmd == "filesize":
            f = input("Nom fichier: ")
            print(os.path.getsize(f),"bytes")

        # UTILITAIRES
        elif cmd.startswith("say "):
            print(cmd[4:])
        elif cmd == "calc":
            expr = input("Calcul> ")
            try:
                print("Résultat:", eval(expr))
            except:
                print("Erreur")
        elif cmd == "banner":
            launch_animation()
        elif cmd == "echo":
            t = input("Texte> ")
            print(t)
        elif cmd == "calendar":
            os.system("cal" if os.name!="nt" else "powershell Get-Date")
        elif cmd == "motd":
            print("Bienvenue dans Tahi-arii CMD !")

        # SYSTEME
        elif cmd == "tasklist":
            os.system("tasklist")
        elif cmd.startswith("kill "):
            os.system(f"taskkill /f /im {cmd[5:]}")
        elif cmd == "cpu":
            os.system("wmic cpu get loadpercentage")
        elif cmd == "ram":
            os.system("wmic OS get FreePhysicalMemory")
        elif cmd == "reboot":
            os.system("shutdown /r /t 5")
        elif cmd == "rebootforce":
            os.system("shutdown /r /f /t 5")
        elif cmd == "shutdown":
            os.system("shutdown /s /t 5")

        # SECURITE
        elif cmd == "/malware!":
            defender = r"C:\Program Files\Windows Defender\MpCmdRun.exe"
            if os.path.exists(defender):
                subprocess.run([defender, "-Scan", "-ScanType", "1"])
            else:
                print("Windows Defender non trouvé.")

        # ANIMATION
        elif cmd == "animate":
            launch_animation()

        else:
            print("Commande inconnue. Tape 'help' pour la liste.")

# --------- EXECUTION ----------
if __name__=="__main__":
    run()